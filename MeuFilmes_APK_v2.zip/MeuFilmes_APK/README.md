# Meu Filmes 2.0 — projeto Android pronto para build

App Android com WebView + interface de streaming, splash, ícone, busca, categorias, favoritos, player e importação M3U/M3U8.

**Uso:** somente playlists/streams autorizados.

## Build automático
O projeto já contém `.github/workflows/build-apk.yml`. Ao colocar esta pasta em um repositório GitHub e executar a Action **Build Meu Filmes APK**, o GitHub Actions gera `app-debug.apk` como artefato.
