package com.meufilmes.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){ fileCallback=cb; Intent i=p.createIntent(); try{startActivityForResult(i,42);}catch(Exception e){return false;} return true; }});
        web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/www/index.html");
    }
    @Override protected void onActivityResult(int r,int c,Intent d){ if(r==42 && fileCallback!=null){ Uri[] u=null; if(c==RESULT_OK && d!=null && d.getData()!=null)u=new Uri[]{d.getData()}; fileCallback.onReceiveValue(u); fileCallback=null;} super.onActivityResult(r,c,d); }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
